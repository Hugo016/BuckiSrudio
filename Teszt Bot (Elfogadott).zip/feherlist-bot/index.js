const {
  Client,
  GatewayIntentBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers
  ]
});

const CHANNEL_ID = '1500817865610235994';
const ROLE_ID = '1072689710557827163';
const TOKEN = 'IDE_IRD_AZ_UJ_RESETELT_TOKENED';

const COOLDOWN_TIME = 60 * 60 * 1000; // 1 óra
const cooldowns = {};
const progress = {};

const questions = [
  {
    question: 'Szabad OOC szidni más játékosokat?',
    answers: ['Igen', 'Nem', 'Csak RP-ben'],
    correct: 1
  },
  {
    question: 'Mit jelent a Metagaming?',
    answers: ['IC információ használata OOC-ben', 'OOC információ használata IC-ben', 'Admin parancs'],
    correct: 1
  },
  {
    question: 'Szabad multiaccountot használni?',
    answers: ['Igen', 'Csak engedéllyel', 'Nem'],
    correct: 2
  },
  {
    question: 'Mi történik halálos sérülés után?',
    answers: ['Mindenre emlékszel', 'Elfelejted az eseményeket', 'Azonnal visszamész'],
    correct: 1
  },
  {
    question: 'Szabad combat logolni?',
    answers: ['Csak ha veszítesz', 'Igen', 'Nem'],
    correct: 2
  },
  {
    question: 'Mennyi ideig nem mehetsz vissza halál után a helyszínre?',
    answers: ['30 perc', '1 óra', 'Azonnal visszamehetsz'],
    correct: 1
  },
  {
    question: 'Túsz nélkül lehet rabolni?',
    answers: ['Igen', 'Nem', 'Csak banknál'],
    correct: 1
  },
  {
    question: 'Szabad beépített túszt használni?',
    answers: ['Igen', 'Csak nagy rablásnál', 'Nem'],
    correct: 2
  },
  {
    question: 'Maximum mennyi ideig tartható fogva egy játékos?',
    answers: ['15 perc', '30 perc + kihallgatás', '2 óra'],
    correct: 1
  },
  {
    question: 'Mit jelent a Powergaming?',
    answers: ['Gyors vezetés', 'Lehetetlen dolgok erőltetése RP-ben', 'Admin hívás'],
    correct: 1
  }
];

client.once('ready', async () => {
  console.log('Bot elindult!');

  const channel = await client.channels.fetch(CHANNEL_ID);

  const embed = new EmbedBuilder()
    .setTitle('Fehérlista teszt')
    .setDescription(
      'Kattints a gombra a teszt elkezdéséhez!\n\n' +
      '✅ Legalább **80%** kell az elfogadáshoz.\n' +
      '⏱️ Sikertelen teszt után **1 óra cooldown** van.'
    )
    .setColor(0xff0000);

  const button = new ButtonBuilder()
    .setCustomId('start_test')
    .setLabel('Teszt elkezdése')
    .setStyle(ButtonStyle.Danger);

  const row = new ActionRowBuilder().addComponents(button);

  await channel.send({ embeds: [embed], components: [row] });
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;

  const userId = interaction.user.id;

  if (interaction.customId === 'start_test') {
    const cooldownEnd = cooldowns[userId];

    if (cooldownEnd && Date.now() < cooldownEnd) {
      const remaining = Math.ceil((cooldownEnd - Date.now()) / 60000);

      return interaction.reply({
        content: `⏱️ Még várnod kell **${remaining} percet**, mielőtt újra próbálkozhatsz.`,
        ephemeral: true
      });
    }

    progress[userId] = { index: 0, score: 0 };
    return sendQuestion(interaction);
  }

  if (interaction.customId.startsWith('ans_')) {
    const data = progress[userId];

    if (!data) {
      return interaction.reply({
        content: 'Előbb indítsd el a tesztet!',
        ephemeral: true
      });
    }

    const q = questions[data.index];
    const answer = Number(interaction.customId.split('_')[1]);

    if (answer === q.correct) data.score++;

    data.index++;

    if (data.index >= questions.length) {
      return finishTest(interaction, data);
    }

    return sendQuestion(interaction);
  }
});

async function sendQuestion(interaction) {
  const data = progress[interaction.user.id];
  const q = questions[data.index];

  const buttons = q.answers.map((answer, i) =>
    new ButtonBuilder()
      .setCustomId(`ans_${i}`)
      .setLabel(answer)
      .setStyle(ButtonStyle.Primary)
  );

  const row = new ActionRowBuilder().addComponents(buttons);

  const embed = new EmbedBuilder()
    .setTitle(`Kérdés ${data.index + 1}/10`)
    .setDescription(q.question)
    .setColor(0xff0000);

  await interaction.reply({
    embeds: [embed],
    components: [row],
    ephemeral: true
  });
}

async function finishTest(interaction, data) {
  const percent = Math.round((data.score / questions.length) * 100);

  let text = `Eredményed: **${percent}%**\n\n`;

  if (percent >= 80) {
    text += '✅ Sikeres teszt! Megkaptad az Elfogadott rangot.';

    const role = interaction.guild.roles.cache.get(ROLE_ID);

    if (role) {
      await interaction.member.roles.add(role);
    } else {
      text += '\n\n⚠️ A rang ID hibás vagy nem található.';
    }
  } else {
    text += '❌ Sikertelen teszt. 1 óra múlva újra próbálhatod.';
    cooldowns[interaction.user.id] = Date.now() + COOLDOWN_TIME;
  }

  delete progress[interaction.user.id];

  const embed = new EmbedBuilder()
    .setTitle('Teszt vége')
    .setDescription(text)
    .setColor(percent >= 80 ? 0x00ff00 : 0xff0000);

  await interaction.reply({
    embeds: [embed],
    ephemeral: true
  });
}

client.login('MTUwMTI5NDY0NTAzOTA3MTI2Mg.GrfHeq.ZRiIoQcU6qETQGobo9olySXaRfYGgEMOVNOaiM');